<?php

    define("HOST", "localhost");
    define("USER_NAME", "id19054771_mds7061");
    define("USER_PASS", "mds7061LL99#");
    define("DB_NAME", "id19054771_ges_hospital");